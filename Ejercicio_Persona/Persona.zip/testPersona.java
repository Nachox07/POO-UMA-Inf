/**
 * Created by nacho on 20/3/16.
 */
public class testPersona {

    public static void main(String[] a) {

        Persona persona1 = new Persona("John Doe","45687301A","john.doe@test.com", "Calle Inventada 23",23);
        Persona persona2 = new Persona("Jane Doe","34587275D","jane.doe@test.com", "Calle Ficticia 14", 21);

        System.out.println(persona1);
        System.out.println(persona2);

    }

}
